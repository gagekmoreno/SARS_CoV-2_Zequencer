import os
from Bio import SeqIO
import subprocess
from shutil import copyfile
import argparse

# note 2019-06-01
# modified this as part of 22476 but did NOT test
# do not be surprised if this code needs to be tweaked to work correctly

# accept command line arguments
parser = argparse.ArgumentParser()
parser.add_argument("gff", help="GFF3 annotation file exported from Geneious")
parser.add_argument("fasta", help="FASTA sequence file exported from Geneious")
parser.add_argument("ref_name", help="Specify name of reference genome")
args = parser.parse_args()

# arguments
gff = args.gff
fasta = args.fasta
seq_id = args.ref_name

def copyReferenceFiles():
    '''
    Copy GFF and FASTA files to reference sequence folder
    '''

    # create reference folder for seq_id if it does not already exist
    if not os.path.exists('ref/' + seq_id):
        os.makedirs('ref/' + seq_id)

    # copy GFF and FASTA files
    copyfile(gff, 'ref/' + seq_id + '/' + seq_id + '.gff')
    copyfile(gff, 'ref/' + seq_id + '/' + 'genes.gff')
    copyfile(fasta, 'ref/' + seq_id + '/' + seq_id + '.fa')
    copyfile(fasta, 'ref/' + seq_id + '/' + 'sequences.fa')

    gff_filename = 'ref/' + seq_id + '/' + seq_id + '.gff'
    fasta_filename = 'ref/' + seq_id + '/' + seq_id + '.fa'

    return (gff_filename, fasta_filename)

def indexFasta(fasta_filename):
    '''
    if FASTA index doesn't exist, run samtools faidx
    '''

    faidx_filename = fasta_filename + '.fai'
    if not os.path.isfile(faidx_filename):
        subprocess.call(['samtools',
                        'faidx',
                        fasta_filename])

def createNovoindex(fasta_filename):
    '''
    if Novoalign index doesn't exist, create it
    '''

    novoindex_filename = fasta_filename + '.nix'
    if not os.path.isfile(novoindex_filename):
        subprocess.call(['novoindex',
                        novoindex_filename,
                        fasta_filename])

    return novoindex_filename

def createSnpeffDb():
    '''
    add genome to SnpEff config file and create required SnpEff database
    '''
    # path to snpeff config file
    # need to specify this in working directory because cannot edit snpEff config in Docker container in place
    snpeff_config = 'ref/' + seq_id + '/' + seq_id + '.config'

    # write snpEff config
    with open(snpeff_config, "w") as myfile:
        myfile.write('data.dir = ..\n')
        myfile.write('lof.ignoreProteinCodingAfter  : 0.95\n')
        myfile.write('lof.ignoreProteinCodingBefore : 0.05\n')
        myfile.write('lof.deleteProteinCodingBases : 0.50\n')
        myfile.write('codon.Standard                                                          : TTT/F, TTC/F, TTA/L, TTG/L+, TCT/S, TCC/S, TCA/S, TCG/S, TAT/Y, TAC/Y, TAA/*, TAG/*, TGT/C, TGC/C, TGA/*, TGG/W, CTT/L, CTC/L, CTA/L, CTG/L+, CCT/P, CCC/P, CCA/P, CCG/P, CAT/H, CAC/H, CAA/Q, CAG/Q, CGT/R, CGC/R, CGA/R, CGG/R, ATT/I, ATC/I, ATA/I, ATG/M+, ACT/T, ACC/T, ACA/T, ACG/T, AAT/N, AAC/N, AAA/K, AAG/K, AGT/S, AGC/S, AGA/R, AGG/R, GTT/V, GTC/V, GTA/V, GTG/V, GCT/A, GCC/A, GCA/A, GCG/A, GAT/D, GAC/D, GAA/E, GAG/E, GGT/G, GGC/G, GGA/G, GGG/G\n')
        myfile.write('\n' + seq_id + '.genome : ' + seq_id)

    # create snpeff database
    cmd = ['snpEff', 'build', '-c', snpeff_config, '-genbank', seq_id]

    subprocess.call(cmd)

    # remove temporary snpeff files
    os.remove('ref/' + seq_id + '/' + 'genes.gff')
    os.remove('ref/' + seq_id + '/' + 'sequences.fa')

def makeRefIndices():
    ncbi_fetch = copyReferenceFiles()
    indexFasta(ncbi_fetch[1])
    createNovoindex(ncbi_fetch[1])
    createSnpeffDb()

# prepare indices
makeRefIndices()