#%% Change working directory from the workspace root to the ipynb file location. Turn this addition off with the DataScience.changeDirOnImportExport setting
# ms-python.python added
import os
try:
	os.chdir(os.path.join(os.getcwd(), 'barcode_counter'))
	print(os.getcwd())
except:
	pass
#%% [markdown]
# # Part 3: ZIKV barcode analysis
#%% [markdown]
# ## Purpose
# 
# Calculates a threshold for inclusion of barcode sequences and filters an input pivot table to include only barcode sequences passing the threshold. The output pivot table contains threshold-passing barcodes and their percentage representation in the sample, as well as the percentage of all non-passing barcodes and the total sum of barcode sequences present in the sample.
#%% [markdown]
# ## Specify dataset arguments
# 
# Set file paths, header names, and the type of threshold calculation preferred.
# 
# **Threshold 'a'** – Lists all possible barcodes that were present in the WT stocks and/or barcode stocks.  This would include barcodes that were >0 in the barcode stocks, but =0 in the WT stocks and vice versa.  Then, the mean frequency and standard deviation of all the barcodes that are not the WT barcode sequence is calculated from the WT stock sequence data.  Threshold 'a' equals this mean + 3x standard deviation.
# 
# **Threshold 'b'** – Lists all  possible barcodes that were present in the WT stocks.  Then, the mean frequency and standard deviation of all the barcodes that are not the WT barcode sequence is calculated from the WT stock sequence data.  Threshold 'b' equals this mean + 3x standard deviation.
# 
# **Threshold 'c'** – Uses the frequency of the most common barcode in the WT sample that was NOT the WT sequence.  When there are replicates of the WT stock, then threshold 'c' uses the highest value across the replicates. We have chosen to use this method.

#%%
# Specify the path to the input pivot table

PIVOT_PATH = 'giant_panda_clean.csv'


# Define the separator (tab or comma)

SEP = ','


# Specify the output file path

OUTPUT_PATH = 'authentic_barcodes.csv'


# Define column header for barcode sequences

BARCODE_SEQ_HEADER = ['barcode_sequence']


# Define column headers for WT clone replicates

WT_HEADERS = ['WT_clone_mpcr_RepA',
              'WT_clone_mpcr_RepB']


# Define column headers for stock replicates

STOCK_HEADERS = ['ZIKV_BC_1_Stock_mpcr_RepA',
                 'ZIKV_BC_1_Stock_mpcr_RepB']


# Set your threshold type (threshold_a, threshold_b, threshold_c)

THRESHOLD_TYPE = 'c'

#%% [markdown]
# Define functions:

#%%
# Creates a list of data columns (excludes barcode sequence column)

def list_data_columns(df):
    columns_list = list(df)
    data_columns_list = columns_list[1:]
    return data_columns_list


# Converts integer counts to floats

def convert_to_float(df,data_columns_list):
    for column in data_columns_list:
        df[column] = df[column].astype('float')
        

# Calculates the percentage for each value in the data column

def calculate_percentages(df,data_columns_list):
    percent_df = df
    for column in data_columns_list:
        barcode_sum = df[column].sum()
        percent_df.loc[:,column] = df.loc[:,column]*100/barcode_sum
    return percent_df


# Concatenates and sorts columns for use in identifying thresholds

def concat_and_sort(df,columns_list):
    frames = []
    i = 0
    while i < len(columns_list):
        frames.append(df[columns_list[i]])
        i+=1
    
    concat_df = pd.concat(frames).sort_values(ascending=False).reset_index(drop=True)
    
    return concat_df

#%% [markdown]
# ## Workflow
# 
# 1. Import pivot table as a pandas dataframe
# 2. Determine the threshold by 3 methods:  
#     a. Average of non-original barcode percentages + 3x standard deviation  
#     b. Average of non-original barcode percentages, excluding those not present in WT sample + 3x standard deviation  
#     c. Percentage of second-most frequent barcode in WT population
# 3. Find "authentic" barcodes in stock replicates
# 4. Filter whole dataframe to include only authentic barcodes
# 5. Output a csv file containing authentic barcodes and their percentage representation, the percentage of all non-authentic barcodes, and the total sum of barcode sequences present in each sample.
#%% [markdown]
# ### 1. Import pivot table as a Pandas dataframe
# 
# This defines a dataframe containing the numbers of each barcode present in each sample.

#%%
import pandas as pd
pd.options.mode.chained_assignment = None

# Import giant pandas table as a pandas dataframe

raw_barcode_counts_df = pd.read_csv(PIVOT_PATH, sep=SEP)

#raw_barcode_counts_df

#%% [markdown]
# ### 2a. Determine threshold for barcode authenticity based on average of barcodes present in stock and wild type samples 
# 
# In this threshold calculation, identify all barcodes present in the wild type and/or stock samples. Pool the two wild type replicates and find the average percentage for all barcodes excluding the original (most prevalent) barcode. The threshold is the average percentage + 3 x standard deviation.
# 
# *This threshold calucation presumes that all but the most prevalent barcode in the wild type replicates is "noise" and not barcodes truly meaningfully represented in the sample. However, the top several barcodes in the wild type replicates will be present at percentages above this threshold.*

#%%
# Create a dataframe containing only WT and stock replicates

bar_wt_stock_headers = BARCODE_SEQ_HEADER + WT_HEADERS + STOCK_HEADERS

threshold_a_df = raw_barcode_counts_df[bar_wt_stock_headers]


# Create a list of all columns in threshold_df except the barcode sequence column

threshold_a_data_columns_list = list_data_columns(threshold_a_df)


# Convert all of the barcode counts from integers to floats

convert_to_float(threshold_a_df,threshold_a_data_columns_list)
    

# Trim threshold_df so it only contains barcodes present in at least one WT or stock replicate

threshold_a_df = threshold_a_df[threshold_a_df.sum(axis=1) > 0]


# Populate threshold_percent_df with the percentage of the total number of barcodes present in each column

threshold_a_percent_df = calculate_percentages(threshold_a_df,threshold_a_data_columns_list)


# Create a dataframe that is all of the WT barcode values concatenated, and sorted

total_mean_a_df = concat_and_sort(threshold_a_percent_df,WT_HEADERS)


# Find the mean of all of the "noise" barcodes
# Starting at index=len(WT_HEADERS) excludes the most prevalent barcodes, one per WT replicate

mean_wt_a = total_mean_a_df.loc[len(WT_HEADERS):].mean()

print('average = ' + str(mean_wt_a))


# Find the standard deviation of the "noise" barcodes

stdev_wt_a = total_mean_a_df.loc[len(WT_HEADERS):].std()

print('stdev = ' + str(stdev_wt_a))


# Calculate the threshold

threshold_a = mean_wt_a + 3*stdev_wt_a

print('threshold A = ' + str(threshold_a))

#%% [markdown]
# ### 2b. Determine threshold for barcode authenticity based on average of barcodes present in wild type samples 
# 
# In this threshold calculation, identify all barcodes present in the wild type samples. Pool the two wild type replicates and find the average percentage for all barcodes excluding the original (most prevalent) barcode. The threshold is the average percentage + 3 x standard deviation.
# 
# *This threshold calucation presumes that all but the most prevalent barcode in the wild type replicates is "noise" and not barcodes truly meaningfully represented in the sample. However, the top several barcodes in the wild type replicates will be present at percentages above this threshold.*

#%%
# Create a dataframe containing only WT replicates

bar_wt_headers = BARCODE_SEQ_HEADER + WT_HEADERS

threshold_b_df = raw_barcode_counts_df[bar_wt_headers]



# Create a list of all columns in threshold_df except the barcode sequence column

threshold_b_data_columns_list = list_data_columns(threshold_b_df)


# Convert all of the barcode counts from integers to floats

convert_to_float(threshold_b_df,threshold_b_data_columns_list)
    

# Trim threshold_df so it only contains barcodes present in at least one WT replicate

threshold_b_df = threshold_b_df[threshold_b_df.sum(axis=1) > 0]


# Populate threshold_percent_df with the percentage of the total number of barcodes present in each column

threshold_b_percent_df = calculate_percentages(threshold_b_df,threshold_b_data_columns_list)


# Create a dataframe that is all of the WT barcode values concatenated, and sorted

total_mean_b_df = concat_and_sort(threshold_b_percent_df,WT_HEADERS)

# Find the mean of all of the "noise" barcodes
# Starting at index=len(WT_HEADERS) excludes the most prevalent barcodes, one per WT replicate

mean_wt_b = total_mean_b_df.loc[len(WT_HEADERS):].mean()

print('average = ' + str(mean_wt_b))


# Find the standard deviation of the "noise" barcodes

stdev_wt_b = total_mean_b_df.loc[len(WT_HEADERS):].std()

print('stdev = ' + str(stdev_wt_b))


# Calculate the threshold

threshold_b = mean_wt_b + 3*stdev_wt_b

print('threshold B = ' + str(threshold_b))

#%% [markdown]
# ### 2c. Determine threshold for barcode authenticity based on prevalence of 2nd most common wild type barcode
# 
# In this threshold calculation, identify all barcodes present in the wild type samples. Calculate each barcode's percentage and set the threshold to be the higher of the second-most prevalent barcode across the wild type replicates.

#%%
# Create a dataframe containing only WT replicates

bar_wt_headers = BARCODE_SEQ_HEADER + WT_HEADERS

threshold_c_df = raw_barcode_counts_df[bar_wt_headers]


# Create a list of all columns in threshold_df except the barcode sequence column

threshold_c_data_columns_list = list_data_columns(threshold_c_df)


# Convert all of the barcode counts from integers to floats

convert_to_float(threshold_c_df,threshold_c_data_columns_list)


# Populate threshold_percent_df with the percentage of the total number of barcodes present in each column

threshold_c_percent_df = calculate_percentages(threshold_c_df,threshold_c_data_columns_list)


# Create a dataframe that is all of the WT barcode values concatenated, and sorted
# The threshold will be the value that comes after the WT headers in the dataframe

threshold_c = concat_and_sort(threshold_c_percent_df,WT_HEADERS).loc[len(WT_HEADERS)]


threshold_c_percent_sorted_df = threshold_c_percent_df.sort_values(WT_HEADERS[0],ascending=False).reset_index(drop=True)


WT_barcode = threshold_c_percent_sorted_df.loc[0,BARCODE_SEQ_HEADER[0]]


print('threshold C = ' + str(threshold_c))

print('WT barcode = ' + WT_barcode)

#%% [markdown]
# ### 3. Find the top barcodes in the stock samples
# 
# Based on a given threshold, return a dataframe of "authentic" barcodes. 

#%%
# Choose threshold from above options

if THRESHOLD_TYPE == 'a':
    threshold = threshold_a
elif THRESHOLD_TYPE == 'b':
    threshold = threshold_b
elif THRESHOLD_TYPE == 'c':
    threshold = threshold_c


# Create a dataframe containing only the stock sample replicates

bar_stock_headers = BARCODE_SEQ_HEADER + STOCK_HEADERS

stock_df = raw_barcode_counts_df[bar_stock_headers]


# Create a list of all columns in threshold_df except the barcode sequence column

stock_data_columns_list = list_data_columns(stock_df)


# Convert all of the barcode counts from integers to floats

convert_to_float(stock_df,stock_data_columns_list)


# Populate stock_percent_df with the percentage of the total number of barcodes present in each column

stock_percent_df = calculate_percentages(stock_df,stock_data_columns_list)

stock_authentic_df = stock_percent_df[(stock_percent_df[STOCK_HEADERS] > threshold).any(axis=1)].sort_values(STOCK_HEADERS[0],ascending=False).reset_index(drop=True)


# If the WT barcode isn't already present in the authentic barcodes list, add it to the dataframe

if ~stock_authentic_df['barcode_sequence'].str.contains(WT_barcode).any():
    wt_df = stock_percent_df[stock_percent_df[BARCODE_SEQ_HEADER[0]].str.match(WT_barcode)]
    
    
    stock_authentic_df = stock_authentic_df.append(wt_df, ignore_index=True)
    

#%% [markdown]
# ### 4. Filter whole dataframe to include only authentic barcodes
# 
# Return a dataframe containing only barcodes deemed "authentic." Sort by the first stock replicate and name barcodes. 

#%%
# Get list of data columns (exclude barcode_sequence column)

data_columns_list = list_data_columns(raw_barcode_counts_df)


# Filter the dataframe to only include barcodes above threshold

raw_barcode_counts_authentic_df = raw_barcode_counts_df[raw_barcode_counts_df[BARCODE_SEQ_HEADER[0]].isin(stock_authentic_df[BARCODE_SEQ_HEADER[0]])].reset_index(drop=True)
    

# For all but the barcode sequence column, convert values to float type

convert_to_float(raw_barcode_counts_authentic_df,data_columns_list)
    

# Create a new dataframe to perform calculations on 

percent_barcodes_df = raw_barcode_counts_authentic_df
    

# Populate percent_barcodes_df with the percentage of the total number of barcodes present in each column

for column in data_columns_list:
    barcode_sum = raw_barcode_counts_df[column].sum()
    
    percent_barcodes_df.loc[:,column] = percent_barcodes_df.loc[:,column]*100/barcode_sum
    

# Round values to 2 decimal places

for column in data_columns_list:
        
    percent_barcodes_df.loc[:,column] = percent_barcodes_df.loc[:,column].round(2)
    
percent_barcodes_df = percent_barcodes_df.sort_values([STOCK_HEADERS[0]], ascending=False).reset_index(drop=True)


# Name each barcode sequence

percent_barcodes_df.insert(0,'barcode_name',range(1,1+len(percent_barcodes_df)))

percent_barcodes_df['barcode_name'] = 'BC_' + percent_barcodes_df['barcode_name'].astype('str')

percent_barcodes_df.loc[percent_barcodes_df['barcode_sequence'] == WT_barcode, 'barcode_name'] = 'BC_WT'


#%%
# Calculate the percentage of all other barcodes

percent_barcodes_df.loc['other'] = 100 - percent_barcodes_df.sum(numeric_only=True)

percent_barcodes_df.loc['other','barcode_name'] = 'other_percent'

percent_barcodes_df.loc['other',BARCODE_SEQ_HEADER[0]] = ''


# Calculate total sum of all barcodes

percent_barcodes_df.loc['sum'] = raw_barcode_counts_df.sum(numeric_only=True).round()

percent_barcodes_df.loc['sum','barcode_name'] = 'sum_counts'

percent_barcodes_df.loc['sum',BARCODE_SEQ_HEADER[0]] = ''



percent_barcodes_df

#%% [markdown]
# ### 5. Output a csv file
# 
# Transpose the above dataframe for easier use in Prism, and output to a csv file.

#%%
percent_barcodes_df.transpose().to_csv(OUTPUT_PATH)


