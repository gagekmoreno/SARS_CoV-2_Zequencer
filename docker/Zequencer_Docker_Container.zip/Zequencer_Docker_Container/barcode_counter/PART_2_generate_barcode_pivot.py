#%% Change working directory from the workspace root to the ipynb file location. Turn this addition off with the DataScience.changeDirOnImportExport setting
# ms-python.python added
import os
try:
	os.chdir(os.path.join(os.getcwd(), 'barcode_counter'))
	print(os.getcwd())
except:
	pass
#%% [markdown]
# ## Introduction
# 
# Manipulate barcode counts in Pandas. Create dataframes and figures for PLOS Pathogens publication.
#%% [markdown]
# ## Specify dataset arguments
# 
# Specify variables that need to be changed depending on the dataset and machine configuration. After these parameters are specified, the rest of the notebook should be runnable automatically.

#%%
# path to folder containing three-column barcode count files
BARCODE_COUNTS_PATH = '03-barcode_counts/'


CSV_OUTPUT_PATH = 'giant_panda_clean.csv'

#%% [markdown]
# ## Functions
# 
# Define functions that will be used in the workflow to analyze barcode counts

#%%
def print_status(status):
    '''print timestamped status update'''
    
    from datetime import datetime
    import logging
    
    log = logging.getLogger(__name__)
    
    print('--[' + datetime.now().strftime('%Y-%m-%d %H:%M:%S') + '] ' + status + '--')
    log.info(status)

def create_temp_file():
    '''create named temporary file
    return temporary file object [0] and path to temporary file [1]'''

    import pathlib
    import tempfile
    
    temp = tempfile.NamedTemporaryFile()    
    return [temp, temp.name]

def create_directory(dir_path):
    '''create directory at specified location if one does not already exist'''
    
    import os
    
    if not os.path.exists(dir_path):
        os.makedirs(dir_path)
        
    return dir_path

def copy_and_overwrite(from_path, to_path):
    '''duplicate folder and file hierarchy'''
    import os
    import shutil
     
    print_status('Copying files from ' + from_path + ' to ' + to_path)
    if os.path.exists(to_path):
        shutil.rmtree(to_path)
    shutil.copytree(from_path, to_path)
    
def find_files_in_path(search_path):
    '''get list of files matching files in search_path'''
    import glob
    
    f = glob.glob(search_path, recursive=True)
    
    return f

def derive_file_name(source_file, find_string, replace_string):
    '''create filename string '''
    
    f = source_file.replace(find_string, replace_string)
    
    return f

def run_command(cmd_list, stdout_file = None, stderr_file = None):
    '''run command with subprocess.call
    if stdout or stderr arguments are passed, save to specified file
    '''
    
    import subprocess
    
    print_status(' '.join(cmd_list)) # print status
    
    # if neither stdout or stderr specified
    if stdout_file is None and stderr_file is None:
        print(cmd_list)
        subprocess.call(cmd_list)
     
    # if only stdout is specified
    elif stdout_file is not None and stderr_file is None:
        with open(stdout_file, 'w') as so:
            subprocess.call(cmd_list, stdout = so)
     
    # if only stderr is specified
    elif stdout_file is None and stderr_file is not None:
        with open(stderr_file, 'w') as se:
            subprocess.call(cmd_list, stderr = se)
     
    # if both stdout and stderr are specified
    elif stdout_file is not None and stderr_file is not None:
        with open(stdout_file, 'w') as so:
            with open(stderr_file, 'w') as se:
                subprocess.call(cmd_list, stdout = so, stderr = se)
    
    else: pass
    
def split_path(source_file):
    '''get path to enclosing folder and basename for source_file'''
    
    import os
    
    source_file_path = os.path.dirname(source_file)
    source_file_basename = os.path.basename(source_file)
    
    return [source_file_path, source_file_basename]
    
def remove_file(source_file):
    '''remove file'''
    
    import os
    
    os.remove(source_file)

def combine_barcode_counts(search_path):
    '''combine three-column barcode count files into giant Pandas dataframe'''
    
    import shutil
    import os
    import glob
    import subprocess
    import pandas as pd

    # make giant panda

    BARCODE_COUNT_FILES = glob.glob(search_path + '/**/*.barcode_counts.txt', recursive=True)

    df = pd.concat((pd.read_csv(f, sep='\t') for f in BARCODE_COUNT_FILES))

    pivot_df = pd.pivot_table(df, index=['barcode_sequence'], values = ['barcode_count'], columns = ['sample_name'])
    
    substitute_zero_pivot_df = pivot_df.fillna(0)
    
    return substitute_zero_pivot_df

def export_df_to_excel(df, excel_file):
    '''export pandas dataframe to excel'''
    
    import pandas as pd
    
    df.to_excel(excel_file)
    
    return excel_file

def export_df_as_csv(df, csv_file):
    '''export pandas dataframe to csv'''
    
    import pandas as pd
    
    df.to_csv(csv_file)
    
    return csv_file


#%%
COMBINED_BARCODE_COUNTS = combine_barcode_counts(BARCODE_COUNTS_PATH)

columns_list = [x[1] for x in list(COMBINED_BARCODE_COUNTS)]

#columns_list.insert(0, 'barcode_sequence')



COMBINED_BARCODE_COUNTS_CLEAN = COMBINED_BARCODE_COUNTS

COMBINED_BARCODE_COUNTS_CLEAN.columns = columns_list

COMBINED_BARCODE_COUNTS_CLEAN = COMBINED_BARCODE_COUNTS.rename_axis('barcode_sequence')


COMBINED_BARCODE_COUNTS_CLEAN

export_df_as_csv(COMBINED_BARCODE_COUNTS_CLEAN, CSV_OUTPUT_PATH)


#%%



