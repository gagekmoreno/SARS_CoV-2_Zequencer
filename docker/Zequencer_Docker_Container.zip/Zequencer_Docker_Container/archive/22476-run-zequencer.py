# %%[markdown]
# ## Introduction

# In 22476 Shelby and I rebuilt Zequencer to use Docker. This will make it easier to distribute the Zequencer tools to other users in the lab and collaborators.

# The purpose of this Notebook is to provide a simple interface for running a conventional Zequencer workflow:

# For a set of sequences to examine:

# - Prepare a reference sequence from NCBI Genbank to map against
# - Downsample FASTQ reads to a reasonable number given effective depth of coverage
# - Map downsampled reads to reference FASTA, call variants, and functionally annotate

# The final outputs include a BAM file that can be visualized in Geneious.

# ## Prerequisites

# To run this workflow, a user needs to download and install Docker.

# After installing Docker, the image containing the tools and scripts needed for Zequencer can be accessed by running:

# ```bash
#  docker pull ddockerreg.chtc.wisc.edu/dhoconno/zequencer:22476
# ```

# The first time the container is downloaded to a new machine, it may take some time. Especially on a slow connection. It should be faster to run each subsequent time.

# ## Files

# On your computer, create a folder that contains the FASTQ files you wish to analyze. If you are going to downsample reads by mapping to a specific reference sequence, make sure that sequence is in the same folder. 

# **Make sure this script file is also in the working directory you created.**

# ## Navigate to working directory containing files to analyze

# If these files were in a folder on my computer named:

# `~/Desktop/sandbox/zequencer-demo`

# The next step is opening a terminal window and navigating to this folder with:

# `cd ~/Desktop/sandbox/zequencer-demo`

# Next, launch the Docker container by typing this command into your terminal window:

# ```bash
#  docker run --user $(id -u):$(id -g) \
# -it -v $(pwd):/scratch -w /scratch \
# ddockerreg.chtc.wisc.edu/dhoconno/zequencer:22476 \
# /bin/bash
# ```

# ## Specify Zequncer parameters
# In the next step we are going to specify parameters for the Zequencer workflow:

#%%
# specify Genbank accession number to use as target for mapping (e.g., 'M33262')

ncbi_accession = 'M33262'

# specify FASTA file to use as target for downsampling reads
downsampling_fasta = './SIVmac239-amplicons.fasta'

# FASTQ paired-end reads to analyze
r1_fastq = './50-m239-1e6_S5_L001_R1_001.fastq'
r2_fastq = './50-m239-1e6_S5_L001_R2_001.fastq'

# downsample to specified number of reads per amplicon
reads_per_amplicon = '1000'

# minimum variant frequency to retain (default = 5%)
minimum_variant_percentage = '0.05'

# exclude reads from mapping shorter than this value
minimum_read_length = '100'

# enable debugging mode (saves a lot of intermediate files)
# do not enable unless you know what you are doing
debugging = False


#%%
import subprocess
import os

def create_ncbi_reference():
	'''run prepareNcbiReference.py'''

	cmd = ['python',
	'/zequencer/scripts/prepareNcbiReference.py',
	ncbi_accession]

	subprocess.call(cmd)

def normalize_read_coverage():
	'''run normalizeShortAmpliconCoverage.py'''
	  
	cmd = ['python',
	'/zequencer/scripts/normalizeShortAmpliconCoverage.py',
	downsampling_fasta,
	r1_fastq,
	r2_fastq,
	reads_per_amplicon]

	subprocess.call(cmd)

	# determine name of downsampled FASTQ files
	# save downsampled FASTQ file to same location
	fastq_basename = os.path.dirname(r1_fastq)

	# if FASTQ_BASENAME is empty because FASTQ file is in current folder explicitly set to '.'
	if fastq_basename == '':
		fastq_basename = '.'

	sample_name = os.path.basename(r1_fastq).split('.')[0]

	downsampled_fastq = fastq_basename + '/' + sample_name + '.' + reads_per_amplicon + '.reads.per.amplicon.fastq.gz'

	return downsampled_fastq

def map_reads_call_variants(fastq):
	'''run mapReadsCallVariants script. Use downsampled FASTQ if avaialble, otherwise use initially specified FASTQ files'''

	cmd = ['python',
	'/zequencer/scripts/mapReadsCallVariants.py',
	ncbi_accession,
	'--fastq',
	fastq,
	'--min_var_percent',
	minimum_variant_percentage,
	'--min_read_length',
	minimum_read_length,
	'--debug',
	str(debugging)]

	subprocess.call(cmd)

if reads_per_amplicon != '':
	# if reads_per_amplicon is specified
	# run commands
	create_ncbi_reference()
	fastq_to_map = normalize_read_coverage()
	map_reads_call_variants(fastq_to_map)
else:
	# if reads_per_amplicon is not specified
	create_ncbi_reference()
	map_reads_call_variants((r1_fastq, r2_fastq))